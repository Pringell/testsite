#!/bin/bash

fio="Зонов Николай Денисович"
dob="11.06.2002"
place="Воронеж"
school="Школа №5"

# 866
echo -e "$fio $dob $place $school" > IB-02vp_Zonov866.txt
iconv -f UTF-8 -t CP866 IB-02vp_Zonov866.txt > IB-02vp_Zonov866_cp866.txt

# 1251
echo -e "$fio $dob $place $school" > IB-02vp_Zonov1251.txt
iconv -f UTF-8 -t CP1251 IB-02vp_Zonov1251.txt > IB-02vp_Zonov1251_cp1251.txt

# UTF-8
echo -e "$fio $dob $place $school" > IB-02vp_Zonovutf8.txt

# KOI-8
echo -e "$fio $dob $place $school" > IB-02vp_Zonovkoi8.txt
iconv -f UTF-8 -t KOI8-R IB-02vp_Zonovkoi8.txt > IB-02vp_Zonovkoi8r.txt