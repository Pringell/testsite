#!/bin/bash

echo 'Creating a variable with cyrillic and latin alphabet'
infotext='Зонов Николай Денисович 11.06.2002 Воронеж Школа №5 Zonov Nikolai Denisovich 11.06.2002 Voronesh School №5'

#Converting all letters to upper case
infotextup=$(tr [абвгдежзийклмнопрстуфхцчшщъыьэюяabcdefghijklmnopqrstuvwxyz] [АБВГДЕЖЗИЙКЛМНОПРСТУФХЦЧШЩЪЫЬЭЮЯABCDEFGHIJKLMNOPQRSTUVWXYZ]<<<$infotext)

echo 'Creating a source file'
for ((i=1; i <= 500000; i++))
do
    echo "$infotextup" >> code_ru_en.txt
done

echo 'File encoding'
iconv -c -t 866 code_ru_en.txt > code_866_ru_en.txt
iconv -c -t WINDOWS-1251 code_ru_en.txt > code_1251_ru_en.txt
iconv -c -t UTF8 code_ru_en.txt > code_utf8_ru_en.txt
iconv -c -t KOI-8 code_ru_en.txt > code_koi8_ru_en.txt

#Decode from win to dos
iconv -c -f WINDOWS-1251 -t 866 code_1251_ru_en.txt > code_1251_866.txt

#Decode from dos to win
iconv -c -f 866 -t WINDOWS-1251 code_866_ru_en.txt > code_866_1251.txt

echo 'Transliteration in source file code_ru_en.txt'
sed 's/А/A/g
s/В/B/g
s/С/C/g
s/Е/E/g
s/Н/H/g
s/К/K/g
s/М/M/g
s/О/O/g
s/Р/P/g
s/Т/T/g
s/Х/X/g
s/У/Y/g
s/a/а/g
s/b/в/g
s/c/с/g
s/e/е/g
s/h/н/g
s/k/к/g
s/m/м/g
s/o/о/g
s/p/р/g
s/t/т/g
s/x/х/g
s/y/у/g' code_ru_en.txt > code_ru_en_transliterated.txt

echo 'Zip all files in directory for labs'
zip 3dlab.zip code_ru_en_transliterated.txt code_866_ru_en.txt code_1251_ru_en.txt code_utf8_ru_en.txt code_koi8_ru_en.txt code_1251_866.txt code_866_1251.txt